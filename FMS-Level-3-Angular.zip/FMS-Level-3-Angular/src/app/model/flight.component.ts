export class Flight{
    flightNo: number;
    carrierName: string;
    flightModel: string;
    seatCapacity: number;
    action: boolean;
}