export class User{
  userId:number;
  userName:string;
  userPhone:number;
  userPassword:string;
  userEmail:string;
  active:boolean;
  roles:string;
}
