﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphicsEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Point startPoint = new Point(150, 25);
        private Point endPoint = new Point(300, 300);
        private Color shapeColor = Color.Black;
        private int shape = 1;
        

        private void OnFileExit(object sender, EventArgs e)
        {
            this.Close();
        }

        private void OnAppearanceColor(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                shapeColor = dlg.Color;  
            }

            Invalidate();
        }

        private void OnFormPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen thePen = new Pen(shapeColor, 4);
            int width = endPoint.X - startPoint.Y;
            int height = endPoint.Y - startPoint.Y;

            switch (shape)
            {
                case 1:
                    g.DrawLine(thePen, startPoint, endPoint);
                    break;
                case 2:
                    g.DrawRectangle(thePen, this.startPoint.X, startPoint.Y, width, height);
                    break;
                case 3:
                    g.DrawEllipse(thePen, this.startPoint.X, startPoint.Y, width, height);
                    break;

            }
        }

        private void OnMouseDown(object sender, MouseEventArgs e)
        {
            this.startPoint = new Point(e.X, e.Y);
        }

        private void OnMouseUp(object sender, MouseEventArgs e)
        {
            this.endPoint = new Point(e.X, e.Y);
            Invalidate();
        }

        private void OnShapeLine(object sender, EventArgs e)
        {
            shape = 1;
            
        }

        private void OnShapeRectangle(object sender, EventArgs e)
        {
            shape = 2;
           
        }

        private void OnShapeEllipse(object sender, EventArgs e)
        {
            shape = 3;
            
        }

        
    }
}
