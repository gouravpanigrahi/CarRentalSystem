﻿using System;

namespace InheritanceDemo
{
    //C# Does not support multiple implementation inheritance no more than one concrete base class
    //C# supports multiple interface inheritance

    public sealed class Line : Shape, IDrawable, IPrintable
    {
        private const string author = "Ravi";
        private readonly string company = "Transflower";
        private Point startPoint, endPoint;


        //constructo chaining concept
        public Line() : this(new Point(0, 0), new Point(0, 0))
        {  //this.startPoint = this.endPoint = new Point(0, 0);
            this.company = "IACSD";
        }
        public Line(Point pt1, Point pt2)
        {
            this.startPoint = pt1;
            this.endPoint = pt2;
        }

        public override void Display()
        {
            Console.WriteLine("Displaying a Line ********");

        }

        public void Draw()
        {

            //Graphics rendring
            //Drawing inbuilt functions to draw lines

            Console.WriteLine("Drawing a Line -----------------");
        }
        public void Print()
        {
            Console.WriteLine("Printing a Line");
        }
        public override string ToString()
        {

            //Overriding ToString mehtod for converting object in the form of string 
            //is very importranct for serialization


            string str = String.Format("StartPoint = {0} , {1}  EndPoint= {2} , {3} ",
                                         startPoint.X, this.startPoint.Y, this.endPoint.X, this.endPoint.Y);
            return str;
        }

        //These behaviour should belong to each and every object created in your runtime

        //finaize-----------------------------Finalize
        // equality check---------------------Equals
        // reflection--------------------------GeType 
        // getting hashcode of object-----------GetHashCode
        //string representation of object-------ToString



    }
}