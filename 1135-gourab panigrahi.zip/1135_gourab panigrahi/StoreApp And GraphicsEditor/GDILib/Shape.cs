﻿using System;

namespace InheritanceDemo
{
    public abstract class Shape
    {
        protected int thickness;
        protected ConsoleColor color;
        public abstract void Display();

    }
}