﻿namespace InheritanceDemo
{
    public class Point
    {
        private int x;
        private int y;


        //Property

        //Property always encapsulate private data members


        public int X
        {
            get { return this.x; }   //getter block
            set { this.x = value; }  //set block
        }

        public int Y
        {
            get { return this.y; }
            set { this.y = value; }
        }


        public Point()
        {
            x = y = 0;
        }
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public override string ToString()
        {
            string str = string.Format("{0} : {1}", x, y);
            return str;
        }
    }
}