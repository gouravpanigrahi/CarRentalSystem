﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catalog
{
    public class Product
    {
        private int id;
        private string title;
        private string description;
        private float unitPrice;
        private int quantity;

        public static int count;

        //function overloading
        public Product()
        {
            this.id = 12;
            this.title = "Lotus";
            this.description = "Worship Flower";
            this.unitPrice = 25;
            this.quantity = 4000;
            count++;
        }
        public Product(int id, string title, string description, float unitPrice, int quantity)
        {
            this.id = id;
            this.title = title;
            this.description = description;
            this.unitPrice = unitPrice;
            this.quantity = quantity;
            count++;

        }
        ~Product()
        {

        }

        //getter and setter
        public void SetTitle(string title)
        {
            this.title = title;
        }
        public string GetTitle()
        {
            return title;
        }

        public static int GetCount()
        {
            return count;
        }

        public int ID
        {
            get { return this.id; }
            set { this.id = value; }
        }

        public string Title
        {
            get { return this.title; }
            set { this.title = value; }
        }

        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }

        public int Quantity
        {
            get { return this.quantity; }
            set { this.quantity = value; }
        }

        public float UnitPrice
        {
            get { return this.unitPrice; }
            set { this.unitPrice = value; }
        }
    }
}