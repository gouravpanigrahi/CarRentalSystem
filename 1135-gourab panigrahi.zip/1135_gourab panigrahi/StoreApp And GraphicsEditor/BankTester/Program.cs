﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Banking;
namespace BankTester
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to ICICI Bank.......");
            Console.WriteLine("Enter Initial Amount for Account Opening");
            double initialBalance = double.Parse(Console.ReadLine());

            Account acct1 = new Account(initialBalance);

            acct1.underBalance += AccountController.BlockAccount;
            acct1.underBalance += AccountController.SendEmailNotification;
            acct1.LimitExceeded += AccountController.SendMessageLimitExceeded;

            Console.WriteLine("Enter Amount to be Withdraw");
            double amount = double.Parse(Console.ReadLine());
            
            
            
            acct1.Withdraw(amount);
            
            Console.WriteLine("Your Balance = {0}", acct1.Balance);

           


            Console.ReadLine();


        }
    }
}
