﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Catalog;
namespace StoreApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private List<Product> products = new List<Product>();
        private int current = 0;
        
        private void OnInsertProduct(object sender, EventArgs e)
        {
            int id = int.Parse(this.txtProductId.Text);
            string title = this.txtProductTitle.Text;
            string description = this.txtProductDescription.Text;
            float Unitprice = float.Parse(this.txtUnitPrice.Text);
            int quantity = int.Parse(this.txtProductQuantity.Text);

            Product theProduct = new Product(id, title, description, Unitprice, quantity);
            this.products.Add(theProduct);
            this.txtProductId.Text = null;
            this.txtProductTitle.Text = null;
            this.txtProductDescription.Text = null;
            this.txtUnitPrice.Text = null;
            this.txtProductQuantity.Text = null;

            




        }

        private void OnUpdateProduct(object sender, EventArgs e)
        {

        }

        private void OnDeleteProduct(object sender, EventArgs e)
        {

        }

        private void OnFirstProduct(object sender, EventArgs e)
        {
            current = 0;
            DisplayProduct(current);
        }

        private void OnPrevProduct(object sender, EventArgs e)
        {
            if (current > 0)
            {
                current--;
            }
            
            DisplayProduct(current);
        }

        private void OnNextProduct(object sender, EventArgs e)
        {
            if(current < this.products.Count-1)
            {
                current++;
            }
            
            DisplayProduct(current);
        }

        private void OnLastProduct(object sender, EventArgs e)
        {
            current = this.products.Count - 1;
            DisplayProduct(current);
        }
        private void DisplayProduct(int index)
        {
            Product theProduct = this.products[index];

           this.txtProductId.Text=theProduct.ID.ToString();
           this.txtProductTitle.Text=theProduct.Title;
            this.txtProductDescription.Text = theProduct.Description;
          this.txtUnitPrice.Text=theProduct.UnitPrice.ToString();
            this.txtProductQuantity.Text = theProduct.Quantity.ToString()  ;


        }
    }
}
