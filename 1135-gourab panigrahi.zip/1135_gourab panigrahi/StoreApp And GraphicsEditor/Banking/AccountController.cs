﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking
{
    public delegate void BankOperation();
    public delegate void IncomeTaxOperation();
    public static class AccountController
    {

        public static void BlockAccount()
        {
            Console.WriteLine("Your Account is BLOCKED Temporary");
        }
        public static void SendEmailNotification()
        {
            Console.WriteLine("Email Notification has been sento to  EmailId");
        }

        public static void SendMessageLimitExceeded()
        {
            Console.WriteLine("Please attach PAN CARD Amount is above 50,000");
        }





    }
}
