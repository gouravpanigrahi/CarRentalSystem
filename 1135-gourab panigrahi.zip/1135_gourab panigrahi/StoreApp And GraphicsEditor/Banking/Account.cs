﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking
{
    public class Account
    {
        //data members
        public int rate;
        public double balance;

        public event BankOperation underBalance;
        public event IncomeTaxOperation LimitExceeded;
        //getter and setters for balance
        public double Balance
        {
            get { return this.balance; }
            set { this.balance = value; }
        }
        //method for checking the balance
        public Account(double initialBalance)
        {
            this.balance = initialBalance;
        }
        //method for deposit amount
        public void Deposit(double amount)
        {
            this.balance += amount;
            Monitor();
        }
        //method for withdraw amount
        public void Withdraw(double amount)
        {
            this.balance -= amount;
            Monitor();
            if(amount > 50000)
            {
                LimitExceeded();
            }
        }
        //
        public void Monitor()
        {
            if(balance < 1000)
            {
                underBalance();
            }
            
        }
        
        public override string ToString()
        {
            return "Balance= " + this.balance;
        }

    }
}
