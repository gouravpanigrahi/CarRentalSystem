import { Component, OnInit } from '@angular/core';
import { Car } from '../model/car.component';
import { ActivatedRoute, Router } from '@angular/router';
import { CarService } from '../services/car.service';

@Component({
  selector: 'app-update-car',
  templateUrl: './update-car.component.html',
  styleUrls: ['./update-car.component.css']
})
export class UpdateCarComponent implements OnInit {
  carNo: number;
  car: Car;
  constructor(private route: ActivatedRoute,private router: Router,
    private carService: CarService) { }

  ngOnInit(){
    this.car=new Car();
    this.carNo=this.route.snapshot.params['carNo'];
    this.carService.viewCar(this.carNo)
      .subscribe(data => {
        console.log(data)
        this.car = data;
      }, error => console.log(error));
  }

  modifyCar() {
    this.carService.modifyCar(this.carNo, this.car)
      .subscribe(data => console.log(data), error => console.log(error));
    this.car = new Car();
    this.gotoList();
  }

  onSubmit() {
    this.modifyCar();
  }

  gotoList() {
    this.router.navigate(['/cars']);
  }
}

