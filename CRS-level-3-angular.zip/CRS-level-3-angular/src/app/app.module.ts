import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { CreateBookingComponent } from './create-booking/create-booking.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { BookingDetailsComponent } from './booking-details/booking-details.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UpdateBookingComponent } from './update-booking/update-booking.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { SignupComponent } from './signup/signup.component';
import { PasswordStrengthMeterModule } from 'angular-password-strength-meter';
import { CreatePlaceComponent } from './create-place/create-place.component';
import { PlaceListComponent } from './place-list/place-list.component';
import { PlaceDetailsComponent } from './place-details/place-details.component';
import { UpdatePlaceComponent } from './update-place/update-place.component';
import { CreateCarComponent } from './create-car/create-car.component';
import { CarDetailsComponent } from './car-details/car-details.component';
import { CarListComponent } from './car-list/car-list.component';
import { UpdateCarComponent } from './update-car/update-car.component';
import { SearchScheduledCarComponent } from './search-scheduled-car/search-scheduled-car.component';
import { AddScheduledCarComponent } from './add-scheduled-car/add-scheduled-car.component';
import { ShowScheduledCarsComponent } from './show-scheduled-cars/show-scheduled-cars.component';
import { ModifyScheduledCarComponent } from './modify-scheduled-car/modify-scheduled-car.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { ListUserComponent } from './list-user/list-user.component';
import { UserPanelComponent } from './user-panel/user-panel.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    CreateBookingComponent,
    BookingListComponent,
    BookingDetailsComponent,
    UpdateBookingComponent,
    HomeComponent,
    LoginComponent,
    LogoutComponent,
    SignupComponent,
    CreatePlaceComponent,
    PlaceListComponent,
    PlaceDetailsComponent,
    UpdatePlaceComponent,
    CreateCarComponent,
    CarDetailsComponent,
    CarListComponent,
    UpdateCarComponent,
    SearchScheduledCarComponent,
    AddScheduledCarComponent,
    ModifyScheduledCarComponent,
    ShowScheduledCarsComponent,
    UserDetailsComponent,
    CreateUserComponent,
    UpdateUserComponent,
    ListUserComponent,
    UserPanelComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    PasswordStrengthMeterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
