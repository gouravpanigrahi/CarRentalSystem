import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddScheduledCarComponent } from './add-scheduled-car.component';

describe('AddScheduledCarComponent', () => {
  let component: AddScheduledCarComponent;
  let fixture: ComponentFixture<AddScheduledCarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddScheduledCarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddScheduledCarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
