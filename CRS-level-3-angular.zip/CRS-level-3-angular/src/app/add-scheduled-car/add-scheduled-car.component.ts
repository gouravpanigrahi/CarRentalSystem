import { Component, OnInit } from '@angular/core';
import { ScheduledCar } from '../model/scheduled-car';
import { ScheduledCarService } from '../services/scheduled-car.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-scheduled-car',
  templateUrl: './add-scheduled-car.component.html',
  styleUrls: ['./add-scheduled-car.component.css']
})
export class AddScheduledCarComponent implements OnInit {

  srcPlace:string;
  dstnPlace:string;
  deptDateTime:string;
  arrDateTime:string;


  scheduleCar:ScheduledCar={scheduleCarId:null, availableSeats:null, car:null,schedule:null};

  constructor(private scheduleCarService: ScheduledCarService, private router: Router, private route: ActivatedRoute) {

  }

  ngOnInit(): void {
  }

  addScheduleCar(scheduleCar,sa,da,ddt,adt){
   // alert(sa+da+ ddt+ adt);
    this.srcPlace=sa;
    this.dstnPlace=da;
    this.deptDateTime=ddt;
    this.arrDateTime=adt;
    this.scheduleCarService.addScheduleCar( scheduleCar,sa,da,ddt,adt).subscribe();
    alert("Schedule Car added");
  }

  idValid:boolean=false;
    validateId(){
        if(this.scheduleCar.scheduleCarId>999){
            this.idValid=true;
        }
        else if(this.scheduleCar.scheduleCarId<1){
            this.idValid=true;
        }else{
            this.idValid=false;
        }
    }

  placeValid:boolean=false;
    validatePlace(a:string, b:string){
        if(a.toLowerCase()===b.toLowerCase()){
            this.placeValid=true;
        }else{
            this.placeValid=false;
        }
        this.enableButton();
  }

  buttonFlag:boolean=false;
    enableButton(){
        this.buttonFlag=!this.idValid&&!this.placeValid;
    }

    add(){

      this.router.navigate(['/scheduledCar/add']);

  }

  view(){

      this.router.navigate(['/scheduledCar/show']);

  }

  search(){

      this.router.navigate(['/scheduledCar/search']);

  }
}
