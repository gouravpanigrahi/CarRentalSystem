export class Car{
    id:number;
    carNo: number;
    carName: string;
    carModel: string;
    seatCapacity: number;
    action: boolean;
}