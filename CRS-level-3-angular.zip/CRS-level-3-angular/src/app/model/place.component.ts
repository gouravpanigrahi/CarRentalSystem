export class Place{

  id:number;
  placeName:string;
  placeCode:string;
  placeLocation:string;
  action: boolean;
}
