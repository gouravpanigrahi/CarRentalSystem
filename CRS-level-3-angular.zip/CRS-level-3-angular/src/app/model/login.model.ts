export class LoginModel{
    username:string;
    password:string;
  }
  