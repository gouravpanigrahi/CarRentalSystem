export class Booking {

  id:number;
  carNo:number;
  bookingDateFrom:Date;
  bookingDateTo:Date;



}
