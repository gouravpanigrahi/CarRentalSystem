import { Schedule } from './schedule';
import { Car } from './car.component';

export class ScheduledCar {
    scheduleCarId: number;
    car: Car;
    availableSeats: number;
    schedule: Schedule;
}
