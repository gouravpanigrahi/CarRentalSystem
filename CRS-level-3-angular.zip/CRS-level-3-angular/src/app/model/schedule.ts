import { Place } from './place.component';

export class Schedule {
    id:number;
    scheduleId: number;
    srcPlace: Place;
    dstnPlace: Place;
    deptDateTime: string;
    arrDateTime: string;
}
