import { Component, OnInit } from '@angular/core';
import { Place } from '../model/place.component';
import { ActivatedRoute, Router } from '@angular/router';
import { PlaceService } from '../services/place.service';

@Component({
  selector: 'app-update-place',
  templateUrl: './update-place.component.html',
  styleUrls: ['./update-place.component.css']
})
export class UpdatePlaceComponent implements OnInit {
  placeCode:string;
  place:Place;
  constructor(private route: ActivatedRoute,private router: Router,
    private placeService: PlaceService) { }

  ngOnInit(){
    this.place = new Place();

    this.placeCode= this.route.snapshot.params['placeCode'];

    this.placeService.viewPlace(this.placeCode)
      .subscribe(data => {
        console.log(data)
        this.place = data;
      }, error => console.log(error));
  }
  updatePlace() {
    this.placeService.modifyPlace(this.placeCode, this.place)
      .subscribe(data => console.log(data), error => console.log(error));
    this.place = new Place();
    this.gotoList();
  }

  onSubmit() {
    this.updatePlace();
  }

  gotoList() {
    this.router.navigate(['/places']);
  }
}

