import { Component, OnInit } from '@angular/core';
import { ScheduledCarService } from '../services/scheduled-car.service';
import { ScheduledCar } from '../model/scheduled-car';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-scheduled-car',
  templateUrl: './search-scheduled-car.component.html',
  styleUrls: ['./search-scheduled-car.component.css']
})
export class SearchScheduledCarComponent implements OnInit {
  scheduleCar:ScheduledCar;
  scheduleCarId:number;
  show:boolean=false;

  constructor(private service: ScheduledCarService, private router: Router) { }

  ngOnInit(): void {
    this.scheduleCar=new ScheduledCar();
  }

  searchScheduleCar(scheduleCarId:number):any{
    this.show=true;
    console.log(scheduleCarId);
    this.service.searchScheduledCar(scheduleCarId).subscribe((scheduleCar:ScheduledCar)=>this.scheduleCar=scheduleCar);
}

idValid:boolean=false;
validateId(){
    if(this.scheduleCarId>999){
        this.idValid=true;
    }
    else if(this.scheduleCarId<1){
        this.idValid=true;
    }else{
        this.idValid=false;
    }
}

    add(){

        this.router.navigate(['/scheduledCar/add']);

    }

    view(){

        this.router.navigate(['/scheduledCar/show']);

    }

    search(){

        this.router.navigate(['/scheduledCar/search']);

    }


}
