import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchScheduledCarComponent } from './search-scheduled-car.component';

describe('SearchScheduledCarComponent', () => {
  let component: SearchScheduledCarComponent;
  let fixture: ComponentFixture<SearchScheduledCarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchScheduledCarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchScheduledCarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
