import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Car } from '../model/car.component';
import { CarService } from '../services/car.service';

@Component({
  selector: 'app-user-panel',
  templateUrl: './user-panel.component.html',
  styleUrls: ['./user-panel.component.css']
})
export class UserPanelComponent implements OnInit {

  cars:Observable<Car[]>;
   
  constructor(private carService: CarService, private router: Router) { }

  ngOnInit(){
    this.reloadData();
  }
  reloadData()
  {
    this.cars=this.carService.viewAllCar();
  }
   
  bookCar(carNo:number){
    console.log("Book Car");
    this.router.navigate(['/createBooking', carNo] );
    
  }
   
 

  

  // viewCar(): void{
  //   this.router.navigate(['cars']);
  // }

  // logOut() {
  //   console.log("LOGOUT");
  //   //this.authenticationService.logOut();
  //   sessionStorage.setItem('role', null);
  //   sessionStorage.setItem('userId', null);
  //   this.router.navigate(['login']);
  //   sessionStorage.removeItem('username');
  //   this.router.navigate(['logout']);
  
  // }

   

}
