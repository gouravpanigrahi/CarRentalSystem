import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CarService {
  private Url = 'http://localhost:9092/car';
  constructor(private http: HttpClient) { }
  viewCar(carNo: number): Observable<any> {
    return this.http.get(`${this.Url}/viewCar/${carNo}`);
  }

  addCar(car: Object): Observable<Object> {
    return this.http.post(`${this.Url}/addCar`, car);
  }

  modifyCar(carNo: number,value:any): Observable<Object> {
    return this.http.put(`${this.Url}/updateCar`, value);
  }

  removeCar(carNo: number): Observable<any> {
    return this.http.delete(`${this.Url}/deleteCar/${carNo}`, { responseType: 'text' });
  }

  viewAllCar(): Observable<any> {
    return this.http.get(`${this.Url}/allCar`);
  }

}
