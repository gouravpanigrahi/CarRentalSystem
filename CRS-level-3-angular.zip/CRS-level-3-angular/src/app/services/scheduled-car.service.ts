import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ScheduledCar } from '../model/scheduled-car';

@Injectable({
  providedIn: 'root'
})

export class ScheduledCarService {
  private SFurl: string;
  constructor(private http: HttpClient) { 
  }

  addScheduleCar(scheduleCar:ScheduledCar,srcPlace,dstnPlace,deptDateTime,arrDateTime){
    let form=new FormData();
    form.append("scheduleCarId", String(scheduleCar.scheduleCarId))
    form.append("availableSeats",String(scheduleCar.availableSeats))
    form.append("car",String(scheduleCar.car))
    form.append("schedule",String(scheduleCar.schedule));
    let params = new HttpParams()
    .set('srcPlace', srcPlace)
    .set('dstnPlace', dstnPlace)
    .set('deptDateTime', deptDateTime)
    .set('arrDateTime', arrDateTime);
    console.log(scheduleCar);
    console.log(params.toString());
   // console.log(form);
    return this.http.post('http://localhost:9092/scheduledCar/add?',form,{params});
  }

  searchScheduledCar(scheduledCarId: number) {
    return this.http.get('http://localhost:9092/scheduledCar/search?carId='+scheduledCarId);
  }

  showScheduleCars(): Observable<any> {
    return this.http.get('http://localhost:9092/scheduledCar/viewAll');
  }

  removeScheduleCar(scheduleCarId:number){
    return this.http.delete('http://localhost:9092/scheduledCar/delete?carId='+scheduleCarId);
 }

 modifyScheduledCar(scheduleCar:ScheduledCar){
   let mForm= new FormData();
   mForm.append("scheduleCarId",String(scheduleCar.scheduleCarId))
   mForm.append("schedule",String(scheduleCar.schedule))
   mForm.append("car",String(scheduleCar.car))
   mForm.append("availableSeats",String(scheduleCar.availableSeats))
   return this.http.put('http://localhost:9092/scheduledCar/modify?',mForm);
 }

}
