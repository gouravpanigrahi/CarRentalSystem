import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Place } from '../model/place.component';

@Injectable({
  providedIn: 'root'
})

export class PlaceService{
  
  private baseUrl = 'http://localhost:9092/place';
  constructor(private httpClient:HttpClient){}

  //Returns list of all airports
  getAllPlaces():Observable<Place[]>{
      return this.httpClient.get<Place[]>(`${this.baseUrl}/allPlace`);
  }

  viewPlace(placeCode: string): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}/viewPlace/${placeCode}`);
  }

  addPlace(place: Object): Observable<Object> {
    return this.httpClient.post(`${this.baseUrl}/addPlace`,place);
  }

  modifyPlace(placeCode: string, value: any): Observable<Object> {
    return this.httpClient.put(`${this.baseUrl}/updatePlace`, value);
  }

  removePlace(placeCode: string): Observable<any> {
    return this.httpClient.delete(`${this.baseUrl}/deletePlace/${placeCode}`, { responseType: 'text' });
  }

  viewAllPlace(): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}/allPlace`);
  }

}
