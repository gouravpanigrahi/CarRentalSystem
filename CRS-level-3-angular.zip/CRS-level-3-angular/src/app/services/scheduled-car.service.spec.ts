import { TestBed } from '@angular/core/testing';

import { ScheduledCarService } from './scheduled-car.service';

describe('ScheduledCarService', () => {
  let service: ScheduledCarService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ScheduledCarService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
