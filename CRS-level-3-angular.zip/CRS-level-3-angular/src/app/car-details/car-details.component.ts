import { Component, OnInit } from '@angular/core';
import { Car } from '../model/car.component';
import { ActivatedRoute, Router } from '@angular/router';
import { CarService } from '../services/car.service';

@Component({
  selector: 'app-car-details',
  templateUrl: './car-details.component.html',
  styleUrls: ['./car-details.component.css']
})
export class CarDetailsComponent implements OnInit {
  carNo: number;
  car: Car;
  constructor(private route: ActivatedRoute,private router: Router,
    private carService: CarService) { }

  ngOnInit() {
    this.car = new Car();

    this.carNo = this.route.snapshot.params['carNo'];

    console.log("Car No:- "+this.carNo);
    
    this.carService.viewCar(this.carNo)
      .subscribe(data => {
        console.log(data)
        this.car = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['cars']);
  }

  bookCar(){
    
  }
}

