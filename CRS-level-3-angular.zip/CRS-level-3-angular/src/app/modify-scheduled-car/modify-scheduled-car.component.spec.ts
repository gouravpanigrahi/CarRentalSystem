import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyScheduledCarComponent } from './modify-scheduled-car.component';

describe('ModifyScheduledCarComponent', () => {
  let component: ModifyScheduledCarComponent;
  let fixture: ComponentFixture<ModifyScheduledCarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyScheduledCarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyScheduledCarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
