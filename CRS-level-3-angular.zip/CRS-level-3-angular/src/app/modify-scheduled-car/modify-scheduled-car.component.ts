import { Component, OnInit } from '@angular/core';
import { ScheduledCar } from '../model/scheduled-car';
import { Router } from '@angular/router';
import { ScheduledCarService } from '../services/scheduled-car.service';

@Component({
  selector: 'app-modify-scheduled-car',
  templateUrl: './modify-scheduled-car.component.html',
  styleUrls: ['./modify-scheduled-car.component.css']
})
export class ModifyScheduledCarComponent implements OnInit {
  scheduleCar:ScheduledCar;
  scheduleCarId:number;
  show:boolean=false;

  mScheduleCar:ScheduledCar;


  constructor(private service: ScheduledCarService, private router: Router) { }

  ngOnInit(): void {
    this.scheduleCar=new ScheduledCar();
  }
  searchScheduleCar(scheduleCarId:number):any{
    this.show=true;
    console.log(scheduleCarId);
    this.service.searchScheduledCar(this.scheduleCarId).subscribe((scheduleCar:ScheduledCar)=>this.scheduleCar=scheduleCar);
  }

  modifyScheduledCar(sId, aSeats, schedule,car){
    this.mScheduleCar={
      scheduleCarId: sId,
      availableSeats: aSeats,
      car: car,
      schedule: schedule};
      console.log(this.mScheduleCar);
      if(this.mScheduleCar==null){
        alert("Scheduled Car not modified");
      }
      this.service.modifyScheduledCar(this.mScheduleCar).subscribe();
      alert("Scheduled Car Modified!");
  }

  idValid:boolean=false;
validateId(){
    if(this.scheduleCarId>999){
        this.idValid=true;
    }
    else if(this.scheduleCarId<1){
        this.idValid=true;
    }else{
        this.idValid=false;
    }
}
    add(){

        this.router.navigate(['/scheduledCar/add']);

    }

    view(){

        this.router.navigate(['/scheduledCar/show']);

    }

    search(){

        this.router.navigate(['/scheduledCar/search']);

    }


}
