import { Component, OnInit } from '@angular/core';
import { Place } from '../model/place.component';
import { PlaceService } from '../services/place.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-place',
  templateUrl: './create-place.component.html',
  styleUrls: ['./create-place.component.css']
})
export class CreatePlaceComponent implements OnInit {
  place: Place=new Place();
  submitted=false;
  constructor(private placeService: PlaceService,private router: Router) { }

  ngOnInit(){
  }
  newEmployee(): void {
    this.submitted = false;
    this.place = new Place();
  }

  save() {
    this.placeService.addPlace(this.place)
      .subscribe(data => console.log(data), error => console.log(error));
    this.place = new Place();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
  gotoList() {
    this.router.navigate(['/places']);
  }

}
