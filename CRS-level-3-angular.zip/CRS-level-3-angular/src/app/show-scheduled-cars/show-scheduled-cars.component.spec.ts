import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowScheduledCarsComponent } from './show-scheduled-cars.component';

describe('ShowScheduledCarsComponent', () => {
  let component: ShowScheduledCarsComponent;
  let fixture: ComponentFixture<ShowScheduledCarsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowScheduledCarsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowScheduledCarsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
