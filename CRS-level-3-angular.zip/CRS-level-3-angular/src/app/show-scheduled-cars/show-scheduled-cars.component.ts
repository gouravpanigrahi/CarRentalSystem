import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ScheduledCarService } from '../services/scheduled-car.service';
import { ScheduledCar } from '../model/scheduled-car';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-show-scheduled-cars',
  templateUrl: './show-scheduled-cars.component.html',
  styleUrls: ['./show-scheduled-cars.component.css']
})
export class ShowScheduledCarsComponent implements OnInit {

  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;
  scheduleCars: Observable<ScheduledCar[]>;

  constructor(private router: Router, private service: ScheduledCarService) { }

  ngOnInit(): void {
    this.service.showScheduleCars().subscribe(
      (data:Observable<ScheduledCar[]>)=>this.scheduleCars=data
    );
  }

  removeScheduleCar(scheduleCarId:number){
    this.service.removeScheduleCar(scheduleCarId).subscribe();
    alert("Deleted");
    location.reload();
}

  add(){

    this.router.navigate(['/scheduledCar/add']);

  }

  view(){

    this.router.navigate(['/scheduledCar/show']);

  }

  search(){

    this.router.navigate(['/scheduledCar/search']);

  }

}
