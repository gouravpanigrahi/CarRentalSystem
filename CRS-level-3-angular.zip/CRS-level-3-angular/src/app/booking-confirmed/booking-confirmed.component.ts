import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-confirmed',
  templateUrl: './booking-confirmed.component.html',
  styleUrls: ['./booking-confirmed.component.css']
})
export class BookingConfirmedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
