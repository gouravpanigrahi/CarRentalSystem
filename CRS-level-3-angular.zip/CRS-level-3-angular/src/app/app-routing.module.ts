import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookingListComponent } from './booking-list/booking-list.component';
import { CreateBookingComponent } from './create-booking/create-booking.component';
import { UpdateBookingComponent } from './update-booking/update-booking.component';
import { BookingDetailsComponent } from './booking-details/booking-details.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { SignupComponent } from './signup/signup.component';
import { PlaceListComponent } from './place-list/place-list.component';
import { CreatePlaceComponent } from './create-place/create-place.component';
import { UpdatePlaceComponent } from './update-place/update-place.component';
import { PlaceDetailsComponent } from './place-details/place-details.component';
import { CarListComponent } from './car-list/car-list.component';
import { CreateCarComponent } from './create-car/create-car.component';
import { UpdateCarComponent } from './update-car/update-car.component';
import { CarDetailsComponent } from './car-details/car-details.component';
import { AddScheduledCarComponent } from './add-scheduled-car/add-scheduled-car.component';
import { ShowScheduledCarsComponent } from './show-scheduled-cars/show-scheduled-cars.component';
import { SearchScheduledCarComponent } from './search-scheduled-car/search-scheduled-car.component';
import { WelcomeAdminComponent } from './welcome-admin/welcome-admin.component';
import { ModifyScheduledCarComponent } from './modify-scheduled-car/modify-scheduled-car.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { ListUserComponent } from './list-user/list-user.component';
import { UserPanelComponent } from './user-panel/user-panel.component';


const routes: Routes = [
  {path: '', redirectTo: 'booking',pathMatch: 'full'},
  {path: 'bookings', component: BookingListComponent},
  {path: 'createBooking/:carNo', component: CreateBookingComponent},
  {path: 'updateBooking/:id', component: UpdateBookingComponent},
  {path: 'bookingDetails/:id', component: BookingDetailsComponent},
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: 'home', component: HomeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'logout', component: LogoutComponent},
  {path: 'signup', component: SignupComponent},
  {path: 'places', component: PlaceListComponent },
  {path: 'addPlace', component: CreatePlaceComponent },
  {path: 'update/:placeCode', component: UpdatePlaceComponent },
  {path: 'details/:placeCode', component:PlaceDetailsComponent },
  {path: 'cars', component: CarListComponent },
  {path: 'addCar', component: CreateCarComponent },
  {path: 'updateCar/:carNo', component: UpdateCarComponent },
  {path: 'carDetails/:carNo', component: CarDetailsComponent },
  {path: 'scheduledCar/add', component:AddScheduledCarComponent},
  {path: 'scheduledCar/show', component:ShowScheduledCarsComponent},
  {path: 'scheduledCar/search', component:SearchScheduledCarComponent},
  {path: 'welcomeAdmin', component:WelcomeAdminComponent},
  {path: 'userPanel', component:UserPanelComponent},
  {path: 'scheduledCar/modify', component: ModifyScheduledCarComponent},
  {path: 'addUser', component: CreateUserComponent},
  {path: 'updateUser/:id', component: UpdateUserComponent},
  {path: 'userDetails/:id', component: UserDetailsComponent},
  {path: 'users', component: ListUserComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents= [
  AddScheduledCarComponent,
  SearchScheduledCarComponent,
  ShowScheduledCarsComponent,
  WelcomeAdminComponent,
  ModifyScheduledCarComponent
]
