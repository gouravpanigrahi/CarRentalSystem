import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome-admin',
  templateUrl: './welcome-admin.component.html',
  styleUrls: ['./welcome-admin.component.css']
})
export class WelcomeAdminComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  addScheduledCar(): void{
    this.router.navigate(['scheduledCar/add']);
  }

  viewScheduledCar(): void{
    this.router.navigate(['scheduledCar/show']);
  }

  searchScheduledCar(): void{
      this.router.navigate(['scheduledCar/search']);
  }

  modifyScheduledCar(): void{
    this.router.navigate(['scheduledCar/modify']);
  }

  addCar(): void{
    this.router.navigate(['addCar']);
  }

  viewCar(): void{
    this.router.navigate(['cars']);
  }

  addPlace(): void{
    this.router.navigate(['addPlace']);
  }

  viewPlace(): void{
    this.router.navigate(['places']);
  }
  
  // logOut() {
  //   console.log("LOGOUT");
    
  //   sessionStorage.removeItem('username');
  //   this.router.navigate(['logout']);
  // }
}
