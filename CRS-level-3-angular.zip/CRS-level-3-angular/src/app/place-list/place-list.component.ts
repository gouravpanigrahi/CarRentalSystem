import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Place } from '../model/place.component';
import { PlaceService } from '../services/place.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-place-list',
  templateUrl: './place-list.component.html',
  styleUrls: ['./place-list.component.css']
})
export class PlaceListComponent implements OnInit {
  places: Observable<Place[]>;
  constructor(private placeService: PlaceService,
  private router: Router) { }
  ngOnInit(){
    this.reloadData();
  }
  reloadData()
  {
    this.places=this.placeService.viewAllPlace();
  }
  removePlace(placeCode:string)
  {
    this.placeService.removePlace(placeCode)
    .subscribe(
      data=>{
        console.log(data);
        this.reloadData();
      },
      error => console.log(error));
  }
  placeDetails(placeCode:string)
  {
    this.router.navigate(['details',placeCode]);
  }
  modifyPlace(placeCode:string)
  {
    this.router.navigate(['update',placeCode]);
  }
}
