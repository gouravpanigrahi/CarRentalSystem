import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Car } from '../model/car.component';
import { CarService } from '../services/car.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-car-list',
  templateUrl: './car-list.component.html',
  styleUrls: ['./car-list.component.css']
})
export class CarListComponent implements OnInit {
  cars:Observable<Car[]>;
  constructor(private carService: CarService, private router: Router) { }

  ngOnInit(){
    this.reloadData();
  }
  reloadData()
  {
    this.cars=this.carService.viewAllCar();
  }
  removeCar(carNo: number)
  {
    this.carService.removeCar(carNo)
    .subscribe(
      data=>{
        console.log(data);
        this.reloadData();
      },
      error=> console.log(error));
  }
  carDetails(carNo:number)
  {
    console.log("CarDetails CarNo:"+carNo);
    
    this.router.navigate(['carDetails',carNo]);
  }
  modifyCar(carNo: number)
  {
    this.router.navigate(['updateCar',carNo]);
  }
}
