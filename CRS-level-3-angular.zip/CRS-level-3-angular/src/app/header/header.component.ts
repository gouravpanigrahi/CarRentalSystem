import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit{

    buttonFlag:boolean;
    username:string;
    user:boolean;
    admin:boolean;

    constructor(private router: Router, private authenticationService: AuthenticationService){}

    ngOnInit(){
        this.user=false;
        this.admin=false;
        if(sessionStorage.getItem('role')==='user'){
            this.user=true;
        }else if(sessionStorage.getItem('role')==='admin'){
            this.admin=true;
        }
        
        this.buttonFlag=this.authenticationService.isUserLoggedIn();
        this.username=sessionStorage.getItem('username');
        if(this.username!=null)
            this.username=this.username.toUpperCase();
    }

    logOut() {
        this.buttonFlag=false;
        console.log("LOGOUT");
        //this.authenticationService.logOut();
        sessionStorage.setItem('role', null);
        sessionStorage.setItem('userId', null);
        //this.router.navigate(['login']);
        sessionStorage.removeItem('username');
        //this.router.navigate(['logout']);    
        this.user=false;
        this.admin=false;
        this.router.navigate(['login']);       
      }

}
